import os
import google.generativeai as genai

# Configure the Gemini API
genai.configure(api_key=os.environ.get("GOOGLE_API_KEY"))

try:
    # List available models
    for model in genai.list_models():
        print(f"Model: {model.name}")
        for method in model.supported_generation_methods:
            print(f"- Supports: {method}")
        print("-" * 20)

except Exception as e:
    print(f"An error occurred: {e}")
    print("Please ensure your GOOGLE_API_KEY environment variable is set correctly.")