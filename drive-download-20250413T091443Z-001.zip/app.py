from flask import Flask, request, jsonify, render_template, session
import google.generativeai as genai
import os

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your_secret_key") # Set a secret key for sessions

genai.configure(api_key=os.environ.get("GOOGLE_API_KEY"))
model = genai.GenerativeModel('models/gemini-1.5-pro-latest')

INSTRUCTION_TO_AVOID_ASTERISKS = "Please respond without using asterisks for emphasis or any other purpose."

@app.route('/')
def index():
    session.setdefault('chat_history', []) # Initialize chat history for the session if it doesn't exist
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    chat_history = session['chat_history']
    chat_history.append({"role": "user", "parts": [user_input]})

    # Add the instruction to avoid asterisks before generating the response
    augmented_history = list(chat_history) # Create a copy to avoid modifying the original session history
    augmented_history.append({"role": "user", "parts": [INSTRUCTION_TO_AVOID_ASTERISKS]})

    try:
        response = model.generate_content(augmented_history)
        ai_response = response.text
        chat_history.append({"role": "model", "parts": [ai_response]})
        session['chat_history'] = chat_history # Update the session with the new history
    except Exception as e:
        ai_response = f"Error generating response: {e}"

    return jsonify({'response': ai_response})

if __name__ == '__main__':
    app.run(debug=True)

    #$env:GOOGLE_API_KEY ="AIzaSyBvubDNITFRCZPzH4UIN7lMavpvGcKszXQ"


# Note: Ensure you have Flask and google-generativeai installed in your environment.
# You can install them using pip:
# pip install Flask google-generativeai
# Make sure to set the GOOGLE_API_KEY environment variable in your deployment environment.
# To run this code follow the steps below:
# 1. Save this code in a file named app.py.
# 2. Create a templates directory and inside it create a file named index.html with the HTML code provided earlier.
# 3. Set your Google API key in the environment variable GOOGLE_API_KEY.
#To set api key in terminal use the command:
#set GOOGLE_API_KEY="AIzaSyBvubDNITFRCZPzH4UIN7lMavpvGcKszXQ"
#$env:GOOGLE_API_KEY ="AIzaSyBvubDNITFRCZPzH4UIN7lMavpvGcKszXQ"
# 4. Run the Flask app using the command: python app.py